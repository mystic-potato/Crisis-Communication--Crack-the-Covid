from django.shortcuts import render,redirect
from django.contrib import messages
from django.contrib.auth.models import User,auth
# Create your views here.

def home(request):
	return render(request,'welcomepage.html')



def login(request):
	if request.method=='POST':
		username=request.POST['username']
		password=request.POST['password']

		user=auth.authenticate(username=username,password=password)
		if user is not None:
			auth.login(request,user)
			messages.info(request,'Logged in successfully')
			return redirect('well')
		
		else:

			messages.info(request,'invalid login credentials')
			return redirect('login')
			
	else:
		return render(request,'loginpage.html')
	
def register(request):
	if request.method=='POST':
		username=request.POST['username']
		
		email=request.POST['email']
		password=request.POST['password']

		user=User.objects.create_user(username=username,email=email,password=password)
		user.save();
		print('user created')
		return redirect('login')

	else:
		return render(request,'index.html')

def well(request):
	return render(request,'well.html')

